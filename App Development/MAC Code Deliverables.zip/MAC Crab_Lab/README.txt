For our app we used the React javascript library.
React allows you to create all-in-one web-based applications using html, css, and javascript.
Inside this folder you will find a build folder as well as a src folder.

Inside of the build folder will be the finalized product that we pushed to our web server. 
Since we created our app with react most of the code inside of this folder is a jumbled unreadable mess.
Hoever if you wish to view the project locally you can open the 'index.html' file in a web browser. We built the app
strictly around an i-pad minis dimensions so it will not display correctly on other devices, however you can use dev-tools
to set the correct aspect-ratio if you wish.

Inside of the src folder you will find the js and css files that we used to make our app.
All of the code we wrote is inside of the 'App.js' file and is writen in JSX (A language that combines html and js).
This code is much more readable and easy to understand however it is also very long due to the entire game's html and js
being contained on one file.
Similarly all of our css code is inside of the 'App.css' file and works completely like html5 standard css.

All code was completed from scratch for this project and no template or guides were used.
If you wish to view the website off of our server go to https://westcs.club/crab_lab/

Thanks and stay crabby - 
	The MAC Team