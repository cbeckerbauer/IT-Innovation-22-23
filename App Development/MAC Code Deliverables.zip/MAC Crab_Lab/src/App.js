import React from 'react';
import './App.css';
import DNA from './images/DNA.png';
import DNAActive from './images/DNA-Active.png';

import Cafeteria from './images/Cafeteria.png';
import CafeteriaActive from './images/Cafeteria-Active.png';
import Botany from './images/Botany.png';
import BotanyActive from './images/Botany-Active.png';
import Administration from './images/Administration.png';
import AdministrationActive from './images/Administration-Active.png';
import Dock from './images/Dock.png';
import DockActive from './images/Dock-Active.png';
import Dorms from './images/Dorms.png';
import DormsActive from './images/Dorms-Active.png';
import Exterior from './images/Exterior.png';
import ExteriorActive from './images/Exterior-Active.png';
import Files from './images/Files.png';
import FilesActive from './images/Files-Active.png';
import Lab from './images/Lab.png';
import LabActive from './images/Lab-Active.png';

import Square from './images/Square.png';
import SquareActive from './images/Square-Active.png';
import Circle from './images/Circle.png';
import CircleActive from './images/Circle-Active.png';
import Triangle from './images/Triangle.png';
import TriangleActive from './images/Triangle-Active.png';

import Question from './images/QuestionMark.png';
import Miniboss from './images/Miniboss.png';

import ConclusionLose from './images/Conclusion Lose.png';
import ConclusionWin from './images/Conclusion Win.png';
import Credits from './images/Credits.png';
import Welcome from './images/Welcome.png';
import Intro1 from './images/Intro Situation.png';
import Intro2 from './images/Intro Boss.png';
import Intro3 from './images/Good Luck.png';


function App() {
	return (
		<Project />
	);
}

function timeout(delay) {
	return new Promise(res => setTimeout(res, delay));
}

var bossHealth = 8;
var bossQuestion = 1;

class Project extends React.Component {
	constructor(props) {
		super();

		let temp = [];
		for (let i = 0; i < 8; i++) {
			temp.push([Square, Circle, Triangle]);
		};

		let temp2 = [SquareActive, CircleActive, TriangleActive];

		this.state = {
			rooms: [
				new Room(Cafeteria, CafeteriaActive, 'Cafeteria', 0),
				new Room(Botany, BotanyActive, 'Botany', 1),
				new Room(Administration, AdministrationActive, 'Administration', 2),
				new Room(Dock, DockActive, 'Dock', 3),
				new Room(Dorms, DormsActive, 'Dorms', 4),
				new Room(Exterior, ExteriorActive, 'Exterior', 5),
				new Room(Files, FilesActive, 'Files', 6),
				new Room(Lab, LabActive, 'Lab', 7)
			],
			keys: [DNA, DNA, DNA, DNA, DNA, DNA, DNA, DNA],
			progress: 0,
			currentPage: -1,
			currentQuestion: 'none',
			shapes: temp,
			activeShapes: temp2,
			chances: [0, 0, 0, 0, 0, 0, 0, 0],
			colorPressed: [-1, -1, -1],
			colorOrder: [-1, -1, -1],
			sequence: 0,
			minibosses: [false, false, false, false, false, false, false, false],
			force: false,
			firewall: [false, false, false, false, false, false, false, false],
			firecount: 0,
			minicount: 0,
		}
	}

	handleRoomClick(room) {
		let obj = document.querySelector('[container="' + room.getName() + '"]');
		obj.style.display = 'flex';
		let obj2 = document.getElementsByClassName('MainContain');
		obj2[0].style.display = 'none';
		let index = this.state.rooms.findIndex((cur) => { return room === cur });
		this.setState({ currentPage: index });
		let name = this.state.rooms[index].getName();
		console.log(this.state.minibosses[room]);
		if (this.state.minibosses[room.getNum()]) {
			console.log('test');
			let MinibossPrompt = document.querySelector('[container="' + name + '"] .MinibossPrompt');
			MinibossPrompt.style.display = 'flex';
		}
	}

	handleReturnClick() {
		let name = this.state.rooms[this.state.currentPage].getName();
		let obj = document.querySelector('[container="' + name + '"]');
		obj.style.display = 'none';
		let obj2 = document.getElementsByClassName('MainContain');
		obj2[0].style.display = 'flex';
		this.setState({ currentPage: -1 });
	}

	handleSpaceClick(qst) {
		let name = this.state.rooms[this.state.currentPage].getName();
		let obj = document.querySelector('[container="' + name + '"] .OptionsContain');
		obj.style.display = 'none';
		let obj2 = document.querySelector('[container="' + name + '"] [question="' + qst + '"]');
		this.setState({ currentQuestion: qst });
		obj2.style.display = 'flex';
	}

	handleAnswerClick(correct, question) {
		let name = this.state.rooms[this.state.currentPage].getName();
		let answer = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] [correct="true"]');
		let incorrect = document.querySelectorAll('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] [correct="false"]');
		let display = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .ReportBox');
		let leave = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .LeaveQuestion');
		let cover = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .Cover');
		let covers = [
			document.querySelector('[container="' + name + '"] .SquareCover'),
			document.querySelector('[container="' + name + '"] .CircleCover'),
			document.querySelector('[container="' + name + '"] .TriangleCover')
		];

		cover.style.display = 'block';

		leave.style.display = 'flex';
		if (correct) {
			display.style.color = '#0d0';
			display.innerHTML = "Correct!";
			answer.style.backgroundColor = '#0c0';
		}
		else {
			display.style.color = '#d00';
			display.innerHTML = "Incorrect - Try Again Next Round!";
		}

		if (correct) {
			this.roomComplete(this.state.rooms[this.state.currentPage])
			let temp = this.state.shapes;
			temp[this.state.currentPage][question] = this.state.activeShapes[question];
			this.setState({ shapes: temp });
			covers[question].style.display = 'block';
		}
	}

	handleTaskContinueClick() {

		let name = this.state.rooms[this.state.currentPage].getName();
		let answer = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] [correct="true"]');
		let incorrect = document.querySelectorAll('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] [correct="false"]');
		let display = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .ReportBox');
		let leave = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .LeaveQuestion');
		let cover = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .Cover');
		let obj = document.querySelector('[container="' + name + '"] .OptionsContain');

		answer.style.backgroundColor = '#414042';
		display.innerHTML = '';
		cover.style.display = 'none';
		leave.style.display = 'none';

		obj.style.display = 'flex';
		let obj2 = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]');
		this.setState({ currentQuestion: 'none' });
		obj2.style.display = 'none';
		this.handleReturnClick();
	}

	roomComplete(room) {
		let temp = this.state.rooms;
		let index = temp.findIndex((cur) => { return room === cur });
		let newRoom = room;
		newRoom.setImg(newRoom.activeImage);
		temp[index] = newRoom
		this.setState({ rooms: temp });
		let temp2 = this.state.keys;
		temp2[this.state.progress] = DNAActive;
		this.setState({ keys: temp2 });
		this.setState({ progress: this.state.progress + 1 });
		console.log(this.state.progress);
		if (this.state.progress === 7) {
			this.displayBossPage();
		}
	}

	handleChanceGenerateClick() {
		let name = this.state.rooms[this.state.currentPage].getName();
		let question = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Question');
		question.style.display = 'none';
		let decision = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .DecisionBox');
		let generator = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .ChanceGenerator');
		let generatorCover = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .GeneratorCover');
		let next = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .LeaveQuestion');
		next.style.display = 'flex';
		next.style.color = '#2d2c2e';
		next.style.backgroundColor = '#89bbfe';
		generatorCover.style.display = 'block';
		generator.style.backgroundColor = '#2d2c2e';
		generator.style.color = '#89bbfe';
		let chance = Math.floor(Math.random() * 5);
		if (chance === 0) {
			//Extra move
			decision.innerHTML = 'You grew an exta leg, you can move again this round!';
		} else if (chance === 1) {
			//Lose a Turn
			decision.innerHTML = 'Slipery slime begins to secrete from your shell, you cant move next turn!';
		} else if (chance === 2) {
			//Spawn a Miniboss
			this.setState({ force: true });
			decision.innerHTML = 'A new pheremone eminates from your shell, a miniboss will spawn somewhere on the map!';
		} else if (chance === 3) {
			//Remove all Minibosses
			this.setState({ minibosses: [false, false, false, false, false, false, false, false] });
			decision.innerHTML = 'Your claws grow to twice their size. They scare all of the minibosses off the map!';
		} else if (chance === 4) {
			//Nothing Happens
			decision.innerHTML = 'The mutation is harmless. Nothing happens.';
		}
	}

	handleChanceContinueClick(question) {
		let name = this.state.rooms[this.state.currentPage].getName();
		let display = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .ResponseBox');
		let leave = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .LeaveQuestion');
		let cover = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]  .GeneratorCover');
		let generator = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .ChanceGenerator');
		let decision = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .DecisionBox');
		let mark = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Question');
		let obj = document.querySelector('[container="' + name + '"] .OptionsContain');
		let covers = [
			document.querySelector('[container="' + name + '"] .SquareCover'),
			document.querySelector('[container="' + name + '"] .CircleCover'),
			document.querySelector('[container="' + name + '"] .TriangleCover')
		];

		cover.style.display = 'none';
		leave.style.display = 'none';
		generator.style.backgroundColor = '#89bbfe'
		generator.style.color = '#2d2c2e'
		decision.innerHTML = '';
		mark.style.display = 'block';

		let tempura = this.state.chances;
		tempura[this.state.currentPage] += 1;
		this.setState({ chances: tempura })
		console.log(this.state.chances);
		if (this.state.chances[this.state.currentPage] === 3) {
			let temp = this.state.shapes;
			temp[this.state.currentPage][question] = this.state.activeShapes[question];
			this.setState({ shapes: temp });
			covers[question].style.display = 'block';
		}

		obj.style.display = 'flex';
		let obj2 = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]');
		this.setState({ currentQuestion: 'none' });
		obj2.style.display = 'none';
		this.handleReturnClick();
	}

	async simonSays() {
		let name = this.state.rooms[this.state.currentPage].getName();
		let start = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .StartGame');
		start.style.display = 'none'
		let game = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Game');
		game.style.display = 'flex';

		let simon = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Simon');
		let colors = [
			document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Red'),
			document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Yellow'),
			document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Green'),
			document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Blue'),
		]

		let temp = this.state.colorOrder;
		for (let i = 0; i < temp.length; i++) {
			temp[i] = Math.floor(Math.random() * 4);
		}
		this.setState({ colorOrder: temp });
		this.run(simon);
	}

	timeout = async ms => new Promise(res => setTimeout(res, ms));

	async run(simon) {
		let delay1 = 500;
		await this.timeout(1000);
		simon.style.backgroundColor = this.setColor(this.state.colorOrder[0]);
		await this.timeout(delay1);
		simon.style.backgroundColor = "#000";
		while (this.state.colorPressed[0] === -1) await timeout(50); // pauses script
		console.log(this.state.colorPressed);

		if (this.state.colorPressed[0] === this.state.colorOrder[0]) {
			let temp1 = this.state.colorPressed;
			temp1[0] = -1;
			this.setState({ colorPressed: temp1 });
			console.log('Round 1 Passed');

			let delay2 = 200;
			await this.timeout(1000);
			simon.style.backgroundColor = this.setColor(this.state.colorOrder[0]);
			await this.timeout(delay2);
			simon.style.backgroundColor = "#000";
			await this.timeout(delay2);
			simon.style.backgroundColor = this.setColor(this.state.colorOrder[1]);
			await this.timeout(delay2);
			simon.style.backgroundColor = "#000";

			while (this.state.colorPressed[0] === -1) await timeout(50); // pauses script

			if (this.state.colorPressed[0] === this.state.colorOrder[0]) {
				console.log('Round 2 Try 1 Passed');
				let temp2 = this.state.colorPressed;
				temp2[0] = -1;
				this.setState({ colorPressed: temp2 });
				this.setState({ sequence: 1 })
				while (this.state.colorPressed[1] === -1) await timeout(50); // pauses script
				if (this.state.colorPressed[1] === this.state.colorOrder[1]) {
					console.log('Round 2 Try 2 Passed');
					let temp3 = this.state.colorPressed;
					temp3[1] = -1;
					this.setState({ colorPressed: temp2 });
					this.setState({ sequence: 0 })
					let delay3 = 150;
					await this.timeout(1000);
					simon.style.backgroundColor = this.setColor(this.state.colorOrder[0]);
					await this.timeout(delay3);
					simon.style.backgroundColor = "#000";
					await this.timeout(delay3);
					simon.style.backgroundColor = this.setColor(this.state.colorOrder[1]);
					await this.timeout(delay3);
					simon.style.backgroundColor = "#000";
					await this.timeout(delay3);
					simon.style.backgroundColor = this.setColor(this.state.colorOrder[2]);
					await this.timeout(delay3);
					simon.style.backgroundColor = "#000";

					while (this.state.colorPressed[0] === -1) await timeout(50); // pauses script

					if (this.state.colorPressed[0] === this.state.colorOrder[0]) {
						console.log('Round 3 Try 1 Passed');
						let temp2 = this.state.colorPressed;
						temp2[0] = -1;
						this.setState({ colorPressed: temp2 });
						this.setState({ sequence: 1 })
						while (this.state.colorPressed[1] === -1) await timeout(50); // pauses script
						if (this.state.colorPressed[1] === this.state.colorOrder[1]) {
							console.log('Round 3 Try 2 Passed');
							let temp3 = this.state.colorPressed;
							temp3[1] = -1;
							this.setState({ colorPressed: temp2 });
							this.setState({ sequence: 2 })
							while (this.state.colorPressed[2] === -1) await timeout(50); // pauses script
							if (this.state.colorPressed[2] === this.state.colorOrder[2]) {
								console.log('Round 3 Try 3 Passed');
								let temp4 = this.state.colorPressed;
								temp4[2] = -1;
								this.setState({ colorPressed: temp2 });
								this.setState({ sequence: 0 })

								this.simonPass();

							}
							else {
								this.simonFail();
							}
						}
						else {
							this.simonFail();
						}
					}
					else {
						this.simonFail();
					}
				}
				else {
					this.simonFail();
				}
			}
			else {
				this.simonFail();
			}
		}
		else {
			this.simonFail();
		}
	}

	simonPass() {
		console.log('Simon Says Was PASSED!');
		let name = this.state.rooms[this.state.currentPage].getName();
		let simon = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Simon');
		let back = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .ReturnButton');
		simon.style.backgroundColor = "#89bbfe";
		simon.innerHTML = 'YOU WIN!<br>FIREWALL<br>ACTIVATED';
		back.style.display = 'flex';
		let temp = this.state.firewall;
		temp[this.state.currentPage] = true;
		this.setState({ firewall: temp });
		this.setState({ firecount: this.state.firecount + 1 });
		this.setState({ minicount: 0 });
	}

	simonFail() {
		console.log('Simon Says was FAILED!')
		let name = this.state.rooms[this.state.currentPage].getName();
		let simon = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .Simon');
		let back = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"] .ReturnButton');
		simon.style.backgroundColor = "#b80c09";
		simon.innerHTML = 'YOU LOSE<br>FIREWALL<br>FAILED';
		back.style.display = 'flex';

	}

	handleColorPress(color) {
		let temp = this.state.colorPressed;
		temp[this.state.sequence] = color;
	}

	setColor(color) {
		if (color === 0) {
			//Red
			return '#f00';
		}
		else if (color === 1) {
			//Yellow
			return '#ff0';
		}
		else if (color === 2) {
			//Green
			return '#0f0';
		}
		else {
			//Blue
			return '#00f';
		}
	}

	handleFireReturnClick(question) {
		let name = this.state.rooms[this.state.currentPage].getName();
		let obj = document.querySelector('[container="' + name + '"] .OptionsContain');
		let covers = [
			document.querySelector('[container="' + name + '"] .SquareCover'),
			document.querySelector('[container="' + name + '"] .CircleCover'),
			document.querySelector('[container="' + name + '"] .TriangleCover')
		];
		obj.style.display = 'flex';
		let obj2 = document.querySelector('[container="' + name + '"] [question="' + this.state.currentQuestion + '"]');
		obj2.style.display = 'none'
		let temp = this.state.shapes;
		temp[this.state.currentPage][question] = this.state.activeShapes[question];
		this.setState({ shapes: temp });
		covers[question].style.display = 'block';
		this.setState({
			currentQuestion: 'none',
			colorPressed: [-1, -1, -1],
			colorOrder: [-1, -1, -1],
			sequence: 0,
		});
		this.handleReturnClick();
	}

	handleRoundClick() {
		let rand = Math.floor(Math.random() * 3);
		if (((this.state.firecount + this.state.minicount) != 8) && (rand === 0 || this.state.force === true)) {
			this.setState({ force: false });
			this.spawnCrab();
		}
	}

	spawnCrab() {
		let temp = this.state.minibosses;
		let room = Math.floor(Math.random() * 8);
		if (this.state.firewall[room] !== true && this.state.minibosses[room] !== true) {
			temp[room] = true;
			this.setState({ minibosses: temp });
			let MiniNotif = document.querySelector('.Mininotif');
			MiniNotif.style.display = 'flex';
			let MiniText = document.querySelector('.MiniText');
			MiniText.innerHTML = 'A Miniboss has spawned in the ' + this.state.rooms[room].getName() + ' area!';
			this.setState({ minicount: this.state.minicount + 1 });
		}
		else {
			this.spawnCrab();
		}
	}

	handleHideNotifClick() {
		let MiniNotif = document.querySelector('.Mininotif');
		MiniNotif.style.display = 'none';
	}

	handleMiniFightClick() {
		let name = this.state.rooms[this.state.currentPage].getName();
		let obj = document.querySelector('[container="' + name + '"] .OptionsContain');
		obj.style.display = 'none';
		let obj2 = document.querySelector('[container="' + name + '"] .MiniGame');
		obj2.style.display = 'flex';
	}

	handleMiniAnswerClick(correct) {
		let name = this.state.rooms[this.state.currentPage].getName();
		let answer = document.querySelector('[container="' + name + '"] .MiniGame [correct="true"]');
		let incorrect = document.querySelectorAll('[container="' + name + '"] .MiniGame [correct="false"]');
		let display = document.querySelector('[container="' + name + '"] .MiniGame  .ReportBox');
		let leave = document.querySelector('[container="' + name + '"] .MiniGame  .LeaveQuestion');
		let cover = document.querySelector('[container="' + name + '"] .MiniGame  .Cover');

		cover.style.display = 'block';
		leave.style.display = 'flex';

		let temp = this.state.minibosses;
		temp[this.state.currentPage] = false;
		this.setState({ minibosses: temp });
		console.log(this.state.minibosses);

		this.setState({minicount: this.state.minicount - 1});

		answer.style.backgroundColor = '#0c0';
		for (let i = 0; i < incorrect.length; i++) {
			incorrect[i].style.backgroundColor = '#c00';
		}

		if (correct) {
			display.style.color = '#0d0';
			display.innerHTML = "Correct!";

		}
		else {
			display.style.color = '#d00';
			display.innerHTML = "Incorrect - You can not move this turn!";
		}
	}

	handleMiniContinueClick() {
		let name = this.state.rooms[this.state.currentPage].getName();
		let display = document.querySelector('[container="' + name + '"] .MiniGame  .ReportBox');
		let answer = document.querySelector('[container="' + name + '"] .MiniGame [correct="true"]');
		let incorrect = document.querySelectorAll('[container="' + name + '"] .MiniGame [correct="false"]');
		let leave = document.querySelector('[container="' + name + '"] .MiniGame  .LeaveQuestion');
		let cover = document.querySelector('[container="' + name + '"] .MiniGame  .Cover');
		let obj = document.querySelector('[container="' + name + '"] .OptionsContain');


		answer.style.backgroundColor = '#414042';
		display.innerHTML = '';
		cover.style.display = 'none';
		leave.style.display = 'none';
		answer.style.backgroundColor = '#2d2c2e';
		for (let i = 0; i < incorrect.length; i++) {
			incorrect[i].style.backgroundColor = '#2d2c2e';
		}

		obj.style.display = 'flex';
		let obj2 = document.querySelector('[container="' + name + '"] .MiniGame');
		obj2.style.display = 'none';
		this.setState({ currentQuestion: 'none' });
		let obj3 = document.querySelector('[container="' + name + '"] .MinibossPrompt');
		obj3.style.display = 'none';

		// this.handleReturnClick();
	}

	displayBossPage() {
		let mainContain = document.querySelector('.MainContain');
		mainContain.style.display = 'none';
		let bossContain = document.querySelector('.BossContain');
		bossContain.style.display = 'flex';
	}

	handleBossStart() {
		let BossCentering = document.querySelector('.BossCentering');
		BossCentering.style.display = "none";
		let Question1 = document.querySelector('[boss="' + bossQuestion + '"]');
		Question1.style.display = 'flex';
	}

	handleBossAnswerClick(correct, points) {
		let answer = document.querySelector('[boss="' + bossQuestion + '"] [correct="true"]');
		let incorrect = document.querySelectorAll('[boss="' + bossQuestion + '"] [correct="false"]');
		let display = document.querySelector('[boss="' + bossQuestion + '"]  .ReportBox');
		let leave = document.querySelector('[boss="' + bossQuestion + '"]  .LeaveQuestion');
		let cover = document.querySelector('[boss="' + bossQuestion + '"] .Cover');
		let hp = document.querySelector('.HealthText');

		cover.style.display = 'block';
		leave.style.display = 'flex';

		answer.style.backgroundColor = '#0c0';
		for (let i = 0; i < incorrect.length; i++) {
			incorrect[i].style.backgroundColor = '#c00';
		}

		if (correct) {
			bossHealth = bossHealth - points;
			display.style.color = '#0d0';
			display.innerHTML = 'Correct!';
		}
		else {
			display.style.color = '#d00';
			display.innerHTML = "Incorrect!";
		}

		bossQuestion++;
		hp.innerHTML = bossHealth;
	}

	handleBossContinueClick() {
		let currentQuestion = document.querySelector('[boss="' + (bossQuestion - 1) + '"]');
		let nextQuestion = document.querySelector('[boss="' + bossQuestion + '"]');
		let endScreen = document.querySelector('.EndScreen');
		let winlose = document.querySelector('.WinLose');

		currentQuestion.style.display = 'none';
		nextQuestion.style.display = 'flex';
		// this.handleReturnClick();
		if(bossHealth <= 0){
			currentQuestion.style.display = 'none';
			nextQuestion.style.display = 'none';
			endScreen.style.display = 'flex';
			winlose.src = ConclusionWin;
		}
		if(bossQuestion == 6 && bossHealth > 0){
			currentQuestion.style.display = 'none';
			nextQuestion.style.display = 'none';
			endScreen.style.display = 'flex';
			winlose.src = ConclusionLose;
		}
	}

	handleWelcomeClick(){
		let Welcome = document.querySelector('.Welcome');
		Welcome.style.display = 'none';
		let Intro1 = document.querySelector('.Intro1');
		Intro1.style.display = 'flex';
	}

	handleIntro1Click(){
		let Intro1 = document.querySelector('.Intro1');
		Intro1.style.display = 'none';
		let Intro2 = document.querySelector('.Intro2');
		Intro2.style.display = 'flex';
	}

	handleIntro2Click(){
		let Intro2 = document.querySelector('.Intro2');
		Intro2.style.display = 'none';
		let Intro3 = document.querySelector('.Intro3');
		Intro3.style.display = 'flex';
	}

	handleIntro3Click(){
		let Intro3 = document.querySelector('.Intro3');
		Intro3.style.display = 'none';
		let Tutorial1 = document.querySelector('.Tutorial1');
		Tutorial1.style.display = 'flex';
	}

	handleTutorial1Click(){
		let Tutorial1 = document.querySelector('.Tutorial1');
		Tutorial1.style.display = 'none';
		let Tutorial2 = document.querySelector('.Tutorial2');
		Tutorial2.style.display = 'flex';
	}

	handleTutorial2Click(){
		let Tutorial2 = document.querySelector('.Tutorial2');
		Tutorial2.style.display = 'none';
		let Tutorial3 = document.querySelector('.Tutorial3');
		Tutorial3.style.display = 'flex';
	}

	handleTutorial3Click(){
		let Tutorial3 = document.querySelector('.Tutorial3');
		Tutorial3.style.display = 'none';
		let Tutorial4 = document.querySelector('.Tutorial4');
		Tutorial4.style.display = 'flex';
	}

	handleTutorial4Click(){
		let Tutorial4 = document.querySelector('.Tutorial4');
		Tutorial4.style.display = 'none';
		let Tutorial5 = document.querySelector('.Tutorial5');
		Tutorial5.style.display = 'flex';
	}

	handleTutorialAnswerClick(){
		let answers = document.querySelectorAll('.Tutorial5 .Answer');
		let display = document.querySelector('.Tutorial5  .ReportBox');
		let leave = document.querySelector('.Tutorial5 .LeaveQuestion');
		let cover = document.querySelector('.Tutorial5 .Cover');

		cover.style.display = 'block';
		leave.style.display = 'flex';
		for (let i = 0; i < answers.length; i++) {
			answers[i].style.backgroundColor = '#0c0';
		}
		display.style.color = '#0d0';
		display.innerHTML = 'Correct!';
	}

	handleTutorial5Click(){
		let Tutorial5 = document.querySelector('.Tutorial5');
		Tutorial5.style.display = 'none';
		let Tutorial6 = document.querySelector('.Tutorial6');
		Tutorial6.style.display = 'flex';
	}

	handleTutorial6Click(){
		let Tutorial6 = document.querySelector('.Tutorial6');
		Tutorial6.style.display = 'none';
		let main = document.querySelector('.MainContain');
		main.style.display = 'flex';
	}

	render() {
		return (
			<div className='ExternalContain'> {/* GET RID OF ME */}
				<div className='TutorialContain'>
					<div className='Welcome' onClick={() => this.handleWelcomeClick()}>
						<img className='WelcomeMessage' src={Welcome}></img>
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
					<div className='Intro1' onClick={() => this.handleIntro1Click()}>
						<img className='WelcomeMessage' src={Intro1}></img>
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
					<div className='Intro2' onClick={() => this.handleIntro2Click()}>
						<img className='WelcomeMessage' src={Intro2}></img>
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
					<div className='Intro3' onClick={() => this.handleIntro3Click()}>
						<img className='WelcomeMessage' src={Intro3}></img>
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
					<div className='Tutorial1' onClick={() => this.handleTutorial1Click()}>
						<div className='WelcomeMessage'><h1>GOAL:</h1><br></br>To win this game you must collect 8 gene sequence keys and then fight a final boss.<br></br><br></br>Each round will consist of each player completing one action.</div>
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
					<div className='Tutorial2' onClick={() => this.handleTutorial2Click()}>
						<div className='WelcomeMessage'><h1>ACTIONS:</h1>Each player has two options each round.<br></br><br></br>
																	<h2>Change Rooms</h2>The player can move to an adjacent room. They will only enter the room and will not interact with any spaces.<br></br><br></br>
																	<h2>Move To a Space</h2>The player can move to a space inside of their room. Players can only move to spaces that are not locked out.</div>
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
					<div className='Tutorial3' onClick={() => this.handleTutorial3Click()}>
						<div className='WelcomeMessage'><h1>SPACES:</h1>There are 3 different spaces in each room.<br></br><br></br>
																	<h2>Tasks</h2>Tasks give the player the chance to collect gene keys. You must complete a task in each room to unlock the boss fight. Tasks lock out after sucsessful completion and can be repeated if they are failed.<br></br><br></br>
																	<h2>Firewalls</h2>Each round there is a 33% chance for a miniboss to spawn in a random room. By completing a firewall in the form of simon says players can prevent miniboss spawns in that room for the rest of the game. Firewalls lock out after their first attempt regardless of success or faiure.<br></br><br></br>
																	<h2>Chances</h2>Chance spaces provide some good old luck into your game. Chance spaces have varying effects that are both positive or negative including gaining another action and losing a turn. Chances lock out after 3 uses.</div>
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
					<div className='Tutorial4' onClick={() => this.handleTutorial4Click()}>
						<div className='WelcomeMessage'><h1>MINIBOSSES:</h1>There is a 33% chance for a miniboss to spawn each round in a random room. Minibosses will only spawn in empty rooms that dont have a firewall. When a miniboss is occupying a room it must be defeated before doing any actions in that room. Figthing a miniboss will count as a players action. If they beat the miniboss they are free to move to a space. However if they are defeated by the miniboss they do not get to continue their turn and the miniboss retreats.</div>
																	
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
					<div className='Tutorial5'>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>PRACTICE QUESTION<br></br>Are you ready to play?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={() => this.handleTutorialAnswerClick()}>
								<span>Heck Yes!</span>
							</div>
							<div className='Answer' onClick={() => this.handleTutorialAnswerClick()}>
								<span>Maybe?</span>
							</div>
							<div className='Answer' onClick={() => this.handleTutorialAnswerClick()}>
								<span>Probably Not!</span>
							</div>
							<div className='Answer' onClick={() => this.handleTutorialAnswerClick()}>
								<span>No! Im to crabby!</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTutorial5Click()}>Continue</div>
					</div>
					<div className='Tutorial6' onClick={() => this.handleTutorial6Click()}>
						<div className='WelcomeMessage'><h1>ITS TIME TO START</h1>Start by choosing someone to go first and then play clockwise. Every time all four players have gone press the "end round" button. Complete tasks in each room, fight minibosses back, and cure the final boss. Good Luck and welcome to CRAB LAB!</div>
																	
						<div className='PressAnywhere'>Press anywhere to continue...</div>
					</div>
				</div>
				<div className='MainContain'>
					<header>
						<span className='HeaderText'>Select Your Room</span>
					</header>
					<div className='Mininotif'>
						<img src={Miniboss} className='Miniboss'></img>
						<div className='MiniText'></div>
						<div className='HideNotif' onClick={() => this.handleHideNotifClick()}>Continue</div>
					</div>
					<div className='RoomContain'>
						<div className='RoomButtonContain'>
							<RoomButton img={this.state.rooms[0].getImg()} handleClick={(e) => this.handleRoomClick(this.state.rooms[0])} />
							<RoomButton img={this.state.rooms[2].getImg()} handleClick={(e) => this.handleRoomClick(this.state.rooms[2])} />
							<RoomButton img={this.state.rooms[4].getImg()} handleClick={(e) => this.handleRoomClick(this.state.rooms[4])} />
							<RoomButton img={this.state.rooms[6].getImg()} handleClick={(e) => this.handleRoomClick(this.state.rooms[6])} />
						</div>
						<div className='RoomButtonContain'>
							<RoomButton img={this.state.rooms[1].getImg()} handleClick={(e) => this.handleRoomClick(this.state.rooms[1])} />
							<RoomButton img={this.state.rooms[3].getImg()} handleClick={(e) => this.handleRoomClick(this.state.rooms[3])} />
							<RoomButton img={this.state.rooms[5].getImg()} handleClick={(e) => this.handleRoomClick(this.state.rooms[5])} />
							<RoomButton img={this.state.rooms[7].getImg()} handleClick={(e) => this.handleRoomClick(this.state.rooms[7])} />
						</div>
					</div>
					<span className='ProgressText'>Collect all 8 genetic keys to gain access to REDACTED</span>
					<div className='ProgressContain'>
						<ProgressBar keys={this.state.keys} />
						<div className='EndRound' onClick={() => this.handleRoundClick()}>End Round</div>
					</div>
				</div>

				<div className='BossContain'>
					<header>
						<span className='HeaderText'>BOSS FIGHT! HP = <span className='HealthText'>8</span></span>
					</header>
					<div className='BossCentering'>
						<div className='BossDescription'>As you connect all of the gene keys together you hear a loud hissing behind you. Your team turns around and watches as the restricted doors slide open. Its time to reclaim the facility!</div>
						<div className='BossStart' onClick={() => this.handleBossStart()}>FIGHT!</div>
					</div>
					<div className='EndScreen'>
						<img className='WinLose'></img>
						<img className='Credits' src={Credits}></img>
					</div>
					<div className='Boss' boss='1'>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>What is the most effective way to save the crabs?</span>
							<span className='DisplayText'>10 23 24 23 04 07 03 14 12 22 07 15 07 15 07 03 01 04 07 12 24</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(true, 3)} correct='true'>
								<span>Genetic Modification</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 3)} correct='false'>
								<span>Genetic Multiplication</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 3)} correct='false'>
								<span>Genome Splicing</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 3)} correct='false'>
								<span>Greenhouse Manipulation</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleBossContinueClick()}>Continue</div>
					</div>
					<div className='Boss' boss='2'>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Is it better to read terms and conditions or trust companies?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 2)} correct='false'>
								<span>Trust Small Companies</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(true, 2)} correct='true'>
								<span>Read Them</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 2)} correct='false'>
								<span>Trust Big Companies</span>
							</div>
							<div className='Answer'>
								<span></span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleBossContinueClick()}>Continue</div>
					</div>
					<div className='Boss' boss='3'>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>What is the longest a crab can live?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>4 years</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>20 seconds</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(true, 1)} correct='true'>
								<span>100 years</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>50 years</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleBossContinueClick()}>Continue</div>
					</div>
					<div className='Boss' boss='4'>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>How many crabs have gone missing in Alaska?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(true, 1)} correct='true'>
								<span>7 Billion</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>4 billion</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>890 million</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>698 thousand</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleBossContinueClick()}>Continue</div>
					</div>
					<div className='Boss' boss='5'>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>How can genetic research help?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>Spongebob</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(true, 1)} correct='true'>
								<span>Increases Resistance and Adaptability</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>Supercrabs</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(true, 1)} correct='true'>
								<span>They eat humans</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleBossContinueClick()}>Continue</div>
					</div>
					<div className='Boss' boss='6'>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>How can genetic rescue help?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>they are all in zoos</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>better species of crabs</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(false, 1)} correct='false'>
								<span>Supercrabs</span>
							</div>
							<div className='Answer' onClick={() => this.handleBossAnswerClick(true, 1)} correct='true'>
								<span>Creates genetic diversity</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleBossContinueClick()}>Continue</div>
					</div>
				</div>

				<div className='SpaceContain' container='Cafeteria' >
					<div className='OptionsContain'>
						<header>
							<span className='HeaderText'>Cafeteria - Select Your Space</span>
						</header>
						<div className='MinibossPrompt'>
							<img className='Miniboss' src={Miniboss}></img>
							<div className='MiniPromptText'>A Miniboss is occupying this room, you must defeat it to continue!</div>
							<div className='MiniFight' onClick={() => this.handleMiniFightClick()}>Start the Fight!</div>
						</div>
						<div className='SpaceButtonContainer'>
							<SpaceButton img={this.state.shapes[0][0]} room='Cafeteria' handleClick={(e) => this.handleSpaceClick('Square')} />
							<div className='SquareCover'></div>
							<SpaceButton img={this.state.shapes[0][1]} room='Cafeteria' handleClick={(e) => this.handleSpaceClick('Circle')} />
							<div className='CircleCover'></div>
							<SpaceButton img={this.state.shapes[0][2]} room='Cafeteria' handleClick={(e) => this.handleSpaceClick('Triangle')} />
							<div className='TriangleCover'></div>
						</div>
						<ReturnButton room='Cafeteria' handleClick={(e) => this.handleReturnClick()} />
					</div>
					<div className='MiniGame'>
						<header>
							<span className='HeaderText'>Cafeteria - MINIBOSS</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>How many legs do crabs have?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(true, 0, 'Task')} correct='true'>
								<span>10</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>29</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>83</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>14</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleMiniContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Square'>
						<header>
							<span className='HeaderText'>Cafeteria - TASK</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Convert this binary to decimal:</span>
							<span className='DisplayText'>1110</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(true, 0, 'Task')} correct='true'>
								<span>14</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 0, 'Task')} correct='false'>
								<span>100</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 0, 'Task')} correct='false'>
								<span>9</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 0, 'Task')} correct='false'>
								<span>7</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTaskContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Circle'>
						<header>
							<span className='HeaderText'>Cafeteria - FIREWALL</span>
						</header>
						<div className='StartGame' onClick={(e) => this.simonSays()}>Begin Playing</div>
						<div className='Game'>
							<div className='Simon'></div>
							<div className='Colors'>
								<div className='Red' onClick={() => this.handleColorPress(0)}></div>
								<div className='Yellow' onClick={() => this.handleColorPress(1)}></div>
								<div className='Green' onClick={() => this.handleColorPress(2)}></div>
								<div className='Blue' onClick={() => this.handleColorPress(3)}></div>
							</div>
						</div>
						<div className='ReturnButton' onClick={() => this.handleFireReturnClick(1)}>Continue</div>
					</div>
					<div className='QuestionContain' question='Triangle'>
						<ChanceQuestion header={'Cafeteria - '} handleGeneratorClick={(e) => this.handleChanceGenerateClick()} handleContinueClick={(e) => this.handleChanceContinueClick(2)} />
					</div>
				</div>

				<div className='SpaceContain' container='Botany' >
					<div className='OptionsContain'>
						<header>
							<span className='HeaderText'>Botany - Select Your Space</span>
						</header>
						<div className='MinibossPrompt'>
							<img className='Miniboss' src={Miniboss}></img>
							<div className='MiniPromptText'>A Miniboss is occupying this room, you must defeat it to continue!</div>
							<div className='MiniFight' onClick={() => this.handleMiniFightClick()}>Start the Fight!</div>
						</div>
						<div className='SpaceButtonContainer'>
							<SpaceButton img={this.state.shapes[1][0]} room='Botany' handleClick={(e) => this.handleSpaceClick('Square')} />
							<div className='SquareCover'></div>
							<SpaceButton img={this.state.shapes[1][1]} room='Botany' handleClick={(e) => this.handleSpaceClick('Circle')} />
							<div className='CircleCover'></div>
							<SpaceButton img={this.state.shapes[1][2]} room='Botany' handleClick={(e) => this.handleSpaceClick('Triangle')} />
							<div className='TriangleCover'></div>
						</div>
						<ReturnButton room='Botany' handleClick={(e) => this.handleReturnClick()} />

					</div>
					<div className='MiniGame'>
						<header>
							<span className='HeaderText'>Botany - MINIBOSS</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>What do crabs typically eat?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(true)} correct='true'>
								<span>meat and plants</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false)} correct='false'>
								<span>plants</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false)} correct='false'>
								<span>meat</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false)} correct='false'>
								<span>insects</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleMiniContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Circle'>
						<header>
							<span className='HeaderText'>Botany - TASK</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Convert this binary to decimal:</span>
							<span className='DisplayText'>100000</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 1, 'Task')} correct='false'>
								<span>20</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(true, 1, 'Task')} correct='true'>
								<span>32</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 1, 'Task')} correct='false'>
								<span>200</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 1, 'Task')} correct='false'>
								<span>15</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTaskContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Square'>
						<header>
							<span className='HeaderText'>Botany - FIREWALL</span>
						</header>
						<div className='StartGame' onClick={(e) => this.simonSays()}>Begin Playing</div>
						<div className='Game'>
							<div className='Simon'></div>
							<div className='Colors'>
								<div className='Red' onClick={() => this.handleColorPress(0)}></div>
								<div className='Yellow' onClick={() => this.handleColorPress(1)}></div>
								<div className='Green' onClick={() => this.handleColorPress(2)}></div>
								<div className='Blue' onClick={() => this.handleColorPress(3)}></div>
							</div>
						</div>
						<div className='ReturnButton' onClick={() => this.handleFireReturnClick(0)}>Continue</div>
					</div>
					<div className='QuestionContain' question='Triangle'>
						<ChanceQuestion header={'Botany - '} handleGeneratorClick={(e) => this.handleChanceGenerateClick()} handleContinueClick={(e) => this.handleChanceContinueClick(2)} />

					</div>
				</div>

				<div className='SpaceContain' container='Administration' >
					<div className='OptionsContain'>
						<header>
							<span className='HeaderText'>Administration - Select Your Space</span>
						</header>
						<div className='MinibossPrompt'>
							<img className='Miniboss' src={Miniboss}></img>
							<div className='MiniPromptText'>A Miniboss is occupying this room, you must defeat it to continue!</div>
							<div className='MiniFight' onClick={() => this.handleMiniFightClick()}>Start the Fight!</div>
						</div>
						<div className='SpaceButtonContainer'>
							<SpaceButton img={this.state.shapes[2][0]} room='Administration' handleClick={(e) => this.handleSpaceClick('Square')} />
							<div className='SquareCover'></div>
							<SpaceButton img={this.state.shapes[2][1]} room='Administration' handleClick={(e) => this.handleSpaceClick('Circle')} />
							<div className='CircleCover'></div>
							<SpaceButton img={this.state.shapes[2][2]} room='Administration' handleClick={(e) => this.handleSpaceClick('Triangle')} />
							<div className='TriangleCover'></div>
						</div>
						<ReturnButton room='Administration' handleClick={(e) => this.handleReturnClick()} />

					</div>
					<div className='MiniGame'>
						<header>
							<span className='HeaderText'>Administration - MINIBOSS</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>How many eggs do crabs lay on average?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>1.5 million</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>7-8 million</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(true, 0, 'Task')} correct='true'>
								<span>2-5 million</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>25 million</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleMiniContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Triangle'>
						<header>
							<span className='HeaderText'>Administration - TASK</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Convert this binary to decimal:</span>
							<span className='DisplayText'>1001011</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>222</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>68</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>69</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(true, 2, 'Task')} correct='true'>
								<span>75</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTaskContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Circle'>
						<header>
							<span className='HeaderText'>Administration - FIREWALL</span>
						</header>
						<div className='StartGame' onClick={(e) => this.simonSays()}>Begin Playing</div>
						<div className='Game'>
							<div className='Simon'></div>
							<div className='Colors'>
								<div className='Red' onClick={() => this.handleColorPress(0)}></div>
								<div className='Yellow' onClick={() => this.handleColorPress(1)}></div>
								<div className='Green' onClick={() => this.handleColorPress(2)}></div>
								<div className='Blue' onClick={() => this.handleColorPress(3)}></div>
							</div>
						</div>
						<div className='ReturnButton' onClick={() => this.handleFireReturnClick(1)}>Continue</div>
					</div>
					<div className='QuestionContain' question='Square'>
						<ChanceQuestion header={'Administration - '} handleGeneratorClick={(e) => this.handleChanceGenerateClick()} handleContinueClick={(e) => this.handleChanceContinueClick(0)} />

					</div>
				</div>

				<div className='SpaceContain' container='Dock' >
					<div className='OptionsContain'>
						<header>
							<span className='HeaderText'>Dock - Select Your Space</span>
						</header>
						<div className='MinibossPrompt'>
							<img className='Miniboss' src={Miniboss}></img>
							<div className='MiniPromptText'>A Miniboss is occupying this room, you must defeat it to continue!</div>
							<div className='MiniFight' onClick={() => this.handleMiniFightClick()}>Start the Fight!</div>
						</div>
						<div className='SpaceButtonContainer'>
							<SpaceButton img={this.state.shapes[3][0]} room='Dock' handleClick={(e) => this.handleSpaceClick('Square')} />
							<div className='SquareCover'></div>
							<SpaceButton img={this.state.shapes[3][1]} room='Dock' handleClick={(e) => this.handleSpaceClick('Circle')} />
							<div className='CircleCover'></div>
							<SpaceButton img={this.state.shapes[3][2]} room='Dock' handleClick={(e) => this.handleSpaceClick('Triangle')} />
							<div className='TriangleCover'></div>
						</div>
						<ReturnButton room='Dock' handleClick={(e) => this.handleReturnClick()} />

					</div>
					<div className='MiniGame'>
						<header>
							<span className='HeaderText'>Dock - MINIBOSS</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>What is the smallest crab?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>King Crab</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Hermit Crab</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Devon Crab</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(true, 0, 'Task')} correct='true'>
								<span>Pea Crab</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleMiniContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Circle'>
						<header>
							<span className='HeaderText'>Dock - TASK</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Convert this decimal to binary:</span>
							<span className='DisplayText'>234</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 1, 'Task')} correct='false'>
								<span>11110110</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(true, 1, 'Task')} correct='true'>
								<span>11101010</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 1, 'Task')} correct='false'>
								<span>111011</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 1, 'Task')} correct='false'>
								<span>0000111</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTaskContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Triangle'>
						<header>
							<span className='HeaderText'>Dock - FIREWALL</span>
						</header>
						<div className='StartGame' onClick={(e) => this.simonSays()}>Begin Playing</div>
						<div className='Game'>
							<div className='Simon'></div>
							<div className='Colors'>
								<div className='Red' onClick={() => this.handleColorPress(0)}></div>
								<div className='Yellow' onClick={() => this.handleColorPress(1)}></div>
								<div className='Green' onClick={() => this.handleColorPress(2)}></div>
								<div className='Blue' onClick={() => this.handleColorPress(3)}></div>
							</div>
						</div>
						<div className='ReturnButton' onClick={() => this.handleFireReturnClick(2)}>Continue</div>
					</div>
					<div className='QuestionContain' question='Square'>
						<ChanceQuestion header={'Dock - '} handleGeneratorClick={(e) => this.handleChanceGenerateClick()} handleContinueClick={(e) => this.handleChanceContinueClick(0)} />

					</div>
				</div>

				<div className='SpaceContain' container='Dorms' >
					<div className='OptionsContain'>
						<header>
							<span className='HeaderText'>Dorms - Select Your Space</span>
						</header>
						<div className='MinibossPrompt'>
							<img className='Miniboss' src={Miniboss}></img>
							<div className='MiniPromptText'>A Miniboss is occupying this room, you must defeat it to continue!</div>
							<div className='MiniFight' onClick={() => this.handleMiniFightClick()}>Start the Fight!</div>
						</div>
						<div className='SpaceButtonContainer'>
							<SpaceButton img={this.state.shapes[4][0]} room='Dorms' handleClick={(e) => this.handleSpaceClick('Square')} />
							<div className='SquareCover'></div>
							<SpaceButton img={this.state.shapes[4][1]} room='Dorms' handleClick={(e) => this.handleSpaceClick('Circle')} />
							<div className='CircleCover'></div>
							<SpaceButton img={this.state.shapes[4][2]} room='Dorms' handleClick={(e) => this.handleSpaceClick('Triangle')} />
							<div className='TriangleCover'></div>
						</div>
						<ReturnButton room='Dorms' handleClick={(e) => this.handleReturnClick()} />

					</div>
					<div className='MiniGame'>
						<header>
							<span className='HeaderText'>Dorms - MINIBOSS</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>What has pushed crabs to migrate further North</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>fishing</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>phishing</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(true, 0, 'Task')} correct='true'>
								<span>climate change</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>this is normal behavior</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleMiniContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Triangle'>
						<header>
							<span className='HeaderText'>Dorms - TASK</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Convert this decimal to binary:</span>
							<span className='DisplayText'>127</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>000111</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>101010</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>111110</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(true, 2, 'Task')} correct='true'>
								<span>1111111</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTaskContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Square'>
						<header>
							<span className='HeaderText'>Dorms - FIREWALL</span>
						</header>
						<div className='StartGame' onClick={(e) => this.simonSays()}>Begin Playing</div>
						<div className='Game'>
							<div className='Simon'></div>
							<div className='Colors'>
								<div className='Red' onClick={() => this.handleColorPress(0)}></div>
								<div className='Yellow' onClick={() => this.handleColorPress(1)}></div>
								<div className='Green' onClick={() => this.handleColorPress(2)}></div>
								<div className='Blue' onClick={() => this.handleColorPress(3)}></div>
							</div>
						</div>
						<div className='ReturnButton' onClick={() => this.handleFireReturnClick(0)}>Continue</div>
					</div>
					<div className='QuestionContain' question='Circle'>
						<ChanceQuestion header={'Dorms - '} handleGeneratorClick={(e) => this.handleChanceGenerateClick()} handleContinueClick={(e) => this.handleChanceContinueClick(1)} />

					</div>
				</div>

				<div className='SpaceContain' container='Exterior' >
					<div className='OptionsContain'>
						<header>
							<span className='HeaderText'>Exterior - Select Your Space</span>
						</header>
						<div className='MinibossPrompt'>
							<img className='Miniboss' src={Miniboss}></img>
							<div className='MiniPromptText'>A Miniboss is occupying this room, you must defeat it to continue!</div>
							<div className='MiniFight' onClick={() => this.handleMiniFightClick()}>Start the Fight!</div>
						</div>
						<div className='SpaceButtonContainer'>
							<SpaceButton img={this.state.shapes[5][0]} room='Exterior' handleClick={(e) => this.handleSpaceClick('Square')} />
							<div className='SquareCover'></div>
							<SpaceButton img={this.state.shapes[5][1]} room='Exterior' handleClick={(e) => this.handleSpaceClick('Circle')} />
							<div className='CircleCover'></div>
							<SpaceButton img={this.state.shapes[5][2]} room='Exterior' handleClick={(e) => this.handleSpaceClick('Triangle')} />
							<div className='TriangleCover'></div>
						</div>
						<ReturnButton room='Exterior' handleClick={(e) => this.handleReturnClick()} />

					</div>
					<div className='MiniGame'>
						<header>
							<span className='HeaderText'>Exterior - MINIBOSS</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Why is the crab population so low?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Preadators</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(true, 0, 'Task')} correct='true'>
								<span>Warming of breeding grrounds</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Lack of desire for children</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Pollution</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleMiniContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Triangle'>
						<header>
							<span className='HeaderText'>Exterior - TASK</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Convert this decimal to binary:</span>
							<span className='DisplayText'>345</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>100001111</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>101001111</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(true, 2, 'Task')} correct='true'>
								<span>101011001</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 2, 'Task')} correct='false'>
								<span>100000001</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTaskContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Circle'>
						<header>
							<span className='HeaderText'>Exterior - FIREWALL</span>
						</header>
						<div className='StartGame' onClick={(e) => this.simonSays()}>Begin Playing</div>
						<div className='Game'>
							<div className='Simon'></div>
							<div className='Colors'>
								<div className='Red' onClick={() => this.handleColorPress(0)}></div>
								<div className='Yellow' onClick={() => this.handleColorPress(1)}></div>
								<div className='Green' onClick={() => this.handleColorPress(2)}></div>
								<div className='Blue' onClick={() => this.handleColorPress(3)}></div>
							</div>
						</div>
						<div className='ReturnButton' onClick={() => this.handleFireReturnClick(1)}>Continue</div>
					</div>
					<div className='QuestionContain' question='Square'>
						<ChanceQuestion header={'Exterior - '} handleGeneratorClick={(e) => this.handleChanceGenerateClick()} handleContinueClick={(e) => this.handleChanceContinueClick(0)} />

					</div>
				</div>

				<div className='SpaceContain' container='Files' >
					<div className='OptionsContain'>
						<header>
							<span className='HeaderText'>Files - Select Your Space</span>
						</header>
						<div className='MinibossPrompt'>
							<img className='Miniboss' src={Miniboss}></img>
							<div className='MiniPromptText'>A Miniboss is occupying this room, you must defeat it to continue!</div>
							<div className='MiniFight' onClick={() => this.handleMiniFightClick()}>Start the Fight!</div>
						</div>
						<div className='SpaceButtonContainer'>
							<SpaceButton img={this.state.shapes[6][0]} room='Files' handleClick={(e) => this.handleSpaceClick('Square')} />
							<div className='SquareCover'></div>
							<SpaceButton img={this.state.shapes[6][1]} room='Files' handleClick={(e) => this.handleSpaceClick('Circle')} />
							<div className='CircleCover'></div>
							<SpaceButton img={this.state.shapes[6][2]} room='Files' handleClick={(e) => this.handleSpaceClick('Triangle')} />
							<div className='TriangleCover'></div>
						</div>
						<ReturnButton room='Files' handleClick={(e) => this.handleReturnClick()} />

					</div>
					<div className='MiniGame'>
						<header>
							<span className='HeaderText'>Files - MINIBOSS</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>What is the natural habitat of crabs?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(true, 0, 'Task')} correct='true'>
								<span>Water and Land</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Air</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Water</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Land</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleMiniContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Square'>
						<header>
							<span className='HeaderText'>Files - TASK</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Prove Your Morals:</span>
							<span className='DisplayText'>What life is most valuable to the Pacific's ecosystem?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Humans</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Lobster</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(true, 0, 'Task')} correct='true'>
								<span>Crabs</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Salmon</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTaskContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Triangle'>
						<header>
							<span className='HeaderText'>Files - FIREWALL</span>
						</header>
						<div className='StartGame' onClick={(e) => this.simonSays()}>Begin Playing</div>
						<div className='Game'>
							<div className='Simon'></div>
							<div className='Colors'>
								<div className='Red' onClick={() => this.handleColorPress(0)}></div>
								<div className='Yellow' onClick={() => this.handleColorPress(1)}></div>
								<div className='Green' onClick={() => this.handleColorPress(2)}></div>
								<div className='Blue' onClick={() => this.handleColorPress(3)}></div>
							</div>
						</div>
						<div className='ReturnButton' onClick={() => this.handleFireReturnClick(2)}>Continue</div>
					</div>
					<div className='QuestionContain' question='Circle'>
						<ChanceQuestion header={'Files - '} handleGeneratorClick={(e) => this.handleChanceGenerateClick()} handleContinueClick={(e) => this.handleChanceContinueClick(1)} />

					</div>
				</div>

				<div className='SpaceContain' container='Lab' >
					<div className='OptionsContain'>
						<header>
							<span className='HeaderText'>Lab - Select Your Space</span>
						</header>
						<div className='MinibossPrompt'>
							<img className='Miniboss' src={Miniboss}></img>
							<div className='MiniPromptText'>A Miniboss is occupying this room, you must defeat it to continue!</div>
							<div className='MiniFight' onClick={() => this.handleMiniFightClick()}>Start the Fight!</div>
						</div>
						<div className='SpaceButtonContainer'>
							<SpaceButton img={this.state.shapes[7][0]} room='Lab' handleClick={(e) => this.handleSpaceClick('Square')} />
							<div className='SquareCover'></div>
							<SpaceButton img={this.state.shapes[7][1]} room='Lab' handleClick={(e) => this.handleSpaceClick('Circle')} />
							<div className='CircleCover'></div>
							<SpaceButton img={this.state.shapes[7][2]} room='Lab' handleClick={(e) => this.handleSpaceClick('Triangle')} />
							<div className='TriangleCover'></div>
						</div>
						<ReturnButton room='Lab' handleClick={(e) => this.handleReturnClick()} />

					</div>
					<div className='MiniGame'>
						<header>
							<span className='HeaderText'>Lab - MINIBOSS</span>
						</header>
						<div className='QuestionDisplay'>
							<span className='DisplayText'>Why are crabs famous?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>They throw awesome raves</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Spongebob</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(true, 0, 'Task')} correct='true'>
								<span>They are a historical food source</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleMiniAnswerClick(false, 0, 'Task')} correct='false'>
								<span>Celebreties</span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleMiniContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Circle'>
						<header>
							<span className='HeaderText'>Lab - TASK</span>
						</header>
						<div className='QuestionDisplay'>
						<span className='DisplayText'>Prove Your Morals:</span>
							<span className='DisplayText'>Should user data on large platforms be sold without explicit consent?</span>
							<span className='ReportBox'>Select an answer below</span>
						</div>
						<div className='Cover'></div>
						<div className='AnswerDisplay'>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(true, 1, 'Task')} correct='true'>
								<span>No</span>
							</div>
							<div className='Answer' onClick={(e) => this.handleAnswerClick(false, 1, 'Task')} correct='false'>
								<span>Yes</span>
							</div>
							<div className='Answer'>
								<span></span>
							</div>
							<div className='Answer'>
								<span></span>
							</div>
						</div>
						<div className='LeaveQuestion' onClick={(e) => this.handleTaskContinueClick()}>Continue</div>
					</div>
					<div className='QuestionContain' question='Triangle'>
						<header>
							<span className='HeaderText'>Lab - FIREWALL</span>
						</header>
						<div className='StartGame' onClick={(e) => this.simonSays()}>Begin Playing</div>
						<div className='Game'>
							<div className='Simon'></div>
							<div className='Colors'>
								<div className='Red' onClick={() => this.handleColorPress(0)}></div>
								<div className='Yellow' onClick={() => this.handleColorPress(1)}></div>
								<div className='Green' onClick={() => this.handleColorPress(2)}></div>
								<div className='Blue' onClick={() => this.handleColorPress(3)}></div>
							</div>
						</div>
						<div className='ReturnButton' onClick={() => this.handleFireReturnClick(2)}>Continue</div>
					</div>
					<div className='QuestionContain' question='Square'>
						<ChanceQuestion header={'Lab - '} handleGeneratorClick={(e) => this.handleChanceGenerateClick()} handleContinueClick={(e) => this.handleChanceContinueClick(0)} />
					</div>
				</div>
			</div >
		)
	}
}

function RoomButton(props) {
	return (
		<button className='RoomButton' onClick={props.handleClick}>
			<img className="RoomIcon" src={props.img} ></img>
		</button>

	)
}

function ProgressBar(props) {
	return (
		<div className='ProgressBar'>
			<ProgressIcon img={props.keys[0]}></ProgressIcon>
			<ProgressIcon img={props.keys[1]}></ProgressIcon>
			<ProgressIcon img={props.keys[2]}></ProgressIcon>
			<ProgressIcon img={props.keys[3]}></ProgressIcon>
			<ProgressIcon img={props.keys[4]}></ProgressIcon>
			<ProgressIcon img={props.keys[5]}></ProgressIcon>
			<ProgressIcon img={props.keys[6]}></ProgressIcon>
			<ProgressIcon img={props.keys[7]}></ProgressIcon>
		</div>
	);
}

function ProgressIcon(props) {
	return (
		<img src={props.img} className='ProgressIcon'></img>
	)
}

function SpaceButton(props) {
	return (
		<button className='SpaceButton' onClick={props.handleClick}>
			<img className="SpaceIcon" src={props.img} ></img>
		</button>

	)
}

function ReturnButton(props) {
	return (
		<button className='BackButton' onClick={props.handleClick}>Go Back</button>
	)
}

function ChanceQuestion(props) {
	return (
		<div className='ChanceContain'>
			<header>
				<span className='HeaderText'>{props.header + 'CHANCE'}</span>
			</header>
			<div className='ChanceDisplay'>
				<img src={Question} className='Question' />
				<span className='DecisionBox'></span>
			</div>
			<div className='ChanceGenerator' onClick={props.handleGeneratorClick}>Press to test Your Luck!</div>
			<div className='GeneratorCover'></div>
			<div className='LeaveQuestion' onClick={props.handleContinueClick}>Continue</div>
		</div>
	)
}

class Room {
	constructor(image, activeImage, name, num) {
		this.img = image;
		this.activeImage = activeImage;
		this.key = DNA;
		this.name = name;
		this.num = num;
	}

	getImg() {
		return this.img;
	}

	setImg(image) {
		this.img = image;
	}

	getNum() {
		return this.num;
	}

	getName() {
		return this.name;
	}

	setName(name) {
		this.name = name;
	}

	getKey() {
		return this.key;
	}

	setKey(src) {
		this.key = src;
	}
}

export default App;
