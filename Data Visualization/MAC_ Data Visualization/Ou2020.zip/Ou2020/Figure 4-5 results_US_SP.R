source("add/helper.R")
library("RColorBrewer")
library(ggplot2)
library(grid)
library(ggrepel)
library(gridExtra)
library(cowplot)
library(ggpubr)
library(scales)
  
# read in data
# ============================================================================

# emission
raw_state_total <- read.csv("04_SP_summary.csv") %>%
  rename(States = region)

# energy
raw_state_ind_coal <- read.csv("05_SP_IND_coal.csv") %>%
  rename(States = region)

raw_state_ind_liquids <- read.csv("05_SP_IND_liquids.csv") %>%
  rename(States = region)

raw_state_bld_biomass <- read.csv("05_SP_BLD_biomass.csv") %>%
  rename(States = region)

raw_state_ele_gen <- read.csv("05_SP_ELE_gen.csv") %>%
  rename(States = region)


mapping <- read.csv("add/00_states_map.csv")

# construct state map
# ============================================================================
states <- map_data("state") %>%
  mutate(States = mapping$region_short[match(paste(region),vecpaste(mapping[c("region")]))])

snames <- data.frame(region=tolower(state.name), long=state.center$x, lat=state.center$y) %>%
  filter(!(region == "alaska" | region == "hawaii")) %>%
  mutate(States = mapping$region_short[match(paste(region),vecpaste(mapping[c("region")]))]) 

snames_repel <- snames %>%
  filter (States %in% c("ME","VT","NH","MA","CT","RI","NJ","MD","DE"))

snames_stay <- snames %>%
  filter (!(States %in% c("ME","VT","NH","MA","CT","RI","NJ","MD","DE")))
# ============================================================================



# ========================================================================
# plots state maps for emissions

sim_states_total <- merge(states, raw_state_total, by = "States")

lmt1 <- 40
VALUE_RANGE <- c(0, 0.25 * lmt1, 0.5 * lmt1, 0.75 * lmt1, lmt1)
LIMIT_RANGE <- c(0, lmt1)

VALUE_RANGE_diff <- c(-30, -3, 0, 0.5, 10)
LIMIT_RANGE_diff <- c(-30, 10)

p1a <- ggplot(sim_states_total, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=ref2015),color="gray47") + 
  scale_fill_gradientn(colours=rev(colorspace::heat_hcl(5)),
                       values=rescale(VALUE_RANGE),
                       limits=LIMIT_RANGE,
                       name = "Billion $  ") + 
  geom_text(data=snames_stay, aes(long, lat, label=States),size=6) +
  geom_text_repel(data=snames_repel, aes(long, lat, label=States), 
                  nudge_x = 5, 
                  segment.color = "gray57", size=6) +
  # coord_map("albers", lat0 = 39, lat1 = 45) +
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="2015")

p1b <- ggplot(sim_states_total, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_REF2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff),
                       limits=LIMIT_RANGE_diff,
                       name = "Billion $  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="REF 2050 minus 2015")

p1c <- ggplot(sim_states_total, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US30_2030),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff),
                       limits=LIMIT_RANGE_diff,
                       name = "Billion $  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US30 2030 minus REF 2030")


p1d <- ggplot(sim_states_total, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US30_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff),
                       limits=LIMIT_RANGE_diff,
                       name = "Billion $  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US30 2050 minus REF 2050")

p1e <- ggplot(sim_states_total, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2030),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff),
                       limits=LIMIT_RANGE_diff,
                       name = "Billion $  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2030 minus REF 2030")


p1f <- ggplot(sim_states_total, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff),
                       limits=LIMIT_RANGE_diff,
                       name = "Billion $  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2050 minus REF 2050")



png(filename = "../../draft/figures/Fig4 state map PMMC.png", width = 7500, height = 7000, res = 400)
par(cex = 2, mar = c(4, 4, 1, 1))
plot_grid(p1a, p1b, p1c, p1d, p1e, p1f, nrow = 3, rel_heights = c(1, 1,1))
dev.off()

png(filename = "../../draft/figures/Fig4 state map PMMC 2050.png", width = 7500, height = 4200, res = 400)
par(cex = 2, mar = c(4, 4, 1, 1))
plot_grid(p1a, p1b, p1d, p1f, nrow = 2, rel_heights = c(1, 1))
dev.off()

png(filename = "../../draft/figures/Fig4 state map PMMC 2030.png", width = 3750, height = 4200, res = 400)
par(cex = 2, mar = c(4, 4, 1, 1))
plot_grid(p1c, p1e, nrow = 2, rel_heights = c(1, 1))
dev.off()

# ========================================================================
# plots state maps for energy


# 1) industry coal
sim_states_ind_coal <- merge(states, raw_state_ind_coal, by = "States")

lmt_ind_coal <- 0.22
VALUE_RANGE_ind_coal <- c(0, 0.25 * lmt_ind_coal, 0.5 * lmt_ind_coal, 0.75 * lmt_ind_coal, lmt_ind_coal)
LIMIT_RANGE_ind_coal <- c(0, lmt_ind_coal)

VALUE_RANGE_diff_ind_coal <- c(-0.2, -0.02, 0, 0.005, 0.051)
LIMIT_RANGE_diff_ind_coal <- c(-0.2, 0.051)

p2a <- ggplot(sim_states_ind_coal, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill= X_2015),color="gray47") + 
  scale_fill_gradientn(colours=rev(colorspace::heat_hcl(5)),
                       values=rescale(VALUE_RANGE_ind_coal),
                       limits=LIMIT_RANGE_ind_coal,
                       name = "EJ  ") + 
  # coord_map("albers", lat0 = 39, lat1 = 45) +
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="2015")

p2b <- ggplot(sim_states_ind_coal, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_REF_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ind_coal),
                       limits=LIMIT_RANGE_diff_ind_coal,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="REF 2050 minus 2015")

p2c <- ggplot(sim_states_ind_coal, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2030),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ind_coal),
                       limits=LIMIT_RANGE_diff_ind_coal,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2030 minus REF 2030")

p2d <- ggplot(sim_states_ind_coal, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ind_coal),
                       limits=LIMIT_RANGE_diff_ind_coal,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2050 minus REF 2050")


# 2) building biomass
sim_states_bld_biomass <- merge(states, raw_state_bld_biomass, by = "States")

lmt_bld_biomass <- 0.042
VALUE_RANGE_bld_biomass <- c(0, 0.25 * lmt_bld_biomass, 0.5 * lmt_bld_biomass, 0.75 * lmt_bld_biomass, lmt_bld_biomass)
LIMIT_RANGE_bld_biomass <- c(0, lmt_bld_biomass)

VALUE_RANGE_diff_bld_biomass <- c(-0.03, -0.003, 0, 0.001, 0.011)
LIMIT_RANGE_diff_bld_biomass <- c(-0.03, 0.011)

p3a <- ggplot(sim_states_bld_biomass, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill= X_2015),color="gray47") + 
  scale_fill_gradientn(colours=rev(colorspace::heat_hcl(5)),
                       values=rescale(VALUE_RANGE_bld_biomass),
                       limits=LIMIT_RANGE_bld_biomass,
                       name = "EJ  ") + 
  # coord_map("albers", lat0 = 39, lat1 = 45) +
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="2015")

p3b <- ggplot(sim_states_bld_biomass, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_REF_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_bld_biomass),
                       limits=LIMIT_RANGE_diff_bld_biomass,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="REF 2050 minus 2015")

p3c <- ggplot(sim_states_bld_biomass, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2030),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_bld_biomass),
                       limits=LIMIT_RANGE_diff_bld_biomass,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2030 minus REF 2030")

p3d <- ggplot(sim_states_bld_biomass, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_bld_biomass),
                       limits=LIMIT_RANGE_diff_bld_biomass,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2050 minus REF 2050")


# 3) electricity generation
sim_states_ele_gen <- merge(states, raw_state_ele_gen, by = "States")

lmt_ele_gen <- 2
VALUE_RANGE_ele_gen <- c(0, 0.25 * lmt_ele_gen, 0.5 * lmt_ele_gen, 0.75 * lmt_ele_gen, lmt_ele_gen)
LIMIT_RANGE_ele_gen <- c(0, lmt_ele_gen)

VALUE_RANGE_diff_ele_gen <- c(-0.41, -0.04, 0, 0.12, 1.21)
LIMIT_RANGE_diff_ele_gen <- c(-0.41, 1.21)

p4a <- ggplot(sim_states_ele_gen, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill= X_2015),color="gray47") + 
  scale_fill_gradientn(colours=rev(colorspace::heat_hcl(5)),
                       values=rescale(VALUE_RANGE_ele_gen),
                       limits=LIMIT_RANGE_ele_gen,
                       name = "EJ  ") + 
  # coord_map("albers", lat0 = 39, lat1 = 45) +
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="2015")

p4b <- ggplot(sim_states_ele_gen, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_REF_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ele_gen),
                       limits=LIMIT_RANGE_diff_ele_gen,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="REF 2050 minus 2015")

p4c <- ggplot(sim_states_ele_gen, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2030),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ele_gen),
                       limits=LIMIT_RANGE_diff_ele_gen,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2030 minus REF 2030")

p4d <- ggplot(sim_states_ele_gen, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ele_gen),
                       limits=LIMIT_RANGE_diff_ele_gen,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2050 minus REF 2050")

png(filename = "test_ele_gen.png", width = 4000, height = 3000, res = 240)
par(cex = 2, mar = c(4, 4, 1, 1))
plot_grid(p4a, p4b, p4c, p4d, ncol = 2, rel_heights = c(1, 1))
dev.off()

# 4) industry liquids
sim_states_ind_liquids <- merge(states, raw_state_ind_liquids, by = "States")

lmt_ind_liquids <- 2.51
VALUE_RANGE_ind_liquids <- c(0, 0.25 * lmt_ind_liquids, 0.5 * lmt_ind_liquids, 0.75 * lmt_ind_liquids, lmt_ind_liquids)
LIMIT_RANGE_ind_liquids <- c(0, lmt_ind_liquids)

VALUE_RANGE_diff_ind_liquids <- c(-0.5, -0.01, 0, 0.151, 1.51)
LIMIT_RANGE_diff_ind_liquids <- c(-0.5, 1.51)

p5a <- ggplot(sim_states_ind_liquids, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill= X_2015),color="gray47") + 
  scale_fill_gradientn(colours=rev(colorspace::heat_hcl(5)),
                       values=rescale(VALUE_RANGE_ind_liquids),
                       limits=LIMIT_RANGE_ind_liquids,
                       name = "EJ  ") + 
  # coord_map("albers", lat0 = 39, lat1 = 45) +
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="2015")

p5b <- ggplot(sim_states_ind_liquids, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_REF_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ind_liquids),
                       limits=LIMIT_RANGE_diff_ind_liquids,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="REF 2050 minus 2015")

p5c <- ggplot(sim_states_ind_liquids, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2030),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ind_liquids),
                       limits=LIMIT_RANGE_diff_ind_liquids,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2030 minus REF 2030")

p5d <- ggplot(sim_states_ind_liquids, aes(long, lat)) + 
  geom_polygon(aes(group=group, fill=dif_US50_2050),color="gray47") + 
  scale_fill_gradientn(colours=colorspace::diverge_hsv(5),
                       values=rescale(VALUE_RANGE_diff_ind_liquids),
                       limits=LIMIT_RANGE_diff_ind_liquids,
                       name = "EJ  ") + 
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        axis.ticks = element_blank(), 
        axis.text = element_blank(),
        axis.line = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 20),
        legend.key.height = unit(1.8, "cm"), 
        legend.text = element_text(size = 20),
        plot.title = element_text(size = 20, face = "bold"),
        axis.title = element_text(size = 25, face = "bold", hjust = 0, vjust = 5)) + 
  labs(y="",x="US50 2050 minus REF 2050")


png(filename = "../../draft/figures/Fig5 state super polluting.png", width = 6000, height = 5000, res = 240)
par(cex = 2, mar = c(4, 4, 1, 1))
plot_grid(p2a, p3a, p5a, p2b, p3b, p5b, p2c, p3c, 
          p5c, p2d, p3d, p5d, ncol = 3, rel_widths = c(1, 1, 1))
dev.off()


png(filename = "../../draft/figures/Fig5 state super polluting 2050.png", width = 6000, height = 3750, res = 240)
par(cex = 2, mar = c(4, 4, 1, 1))
plot_grid(p2a, p3a, p5a, p2b, p3b, p5b, 
          p2d, p3d, p5d, ncol = 3, rel_widths = c(1, 1, 1))
dev.off()

png(filename = "../../draft/figures/Fig5 state super polluting 2030.png", width = 6000, height = 2500, res = 240)
par(cex = 2, mar = c(4, 4, 1, 1))
plot_grid(p2a, p3a, p5a, p2c, p3c, p5c, ncol = 3, rel_widths = c(1, 1, 1))
dev.off()






