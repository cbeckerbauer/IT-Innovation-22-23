# The GCAM R header file
# Ben Bond-Lamberty August 2011, updated February 2012

# This file should be source'd by any R script involved in the processing of GCAM input data
# It provides various facilities, including logging, file I/O and definition of common settings

# -----------------------------------------------------------------------------
# Load required libraries
libs <- c( "reshape2", "stringr", "tidyr","assertr","dplyr" )
for( i in libs ) {
	if( !require( i, character.only=T ) ) {
		cat( "Couldn't load", i, "; trying to download it...\n" )
		install.packages( i )
	}
	library( i, character.only=T )
}


# -----------------------------------------------------------------------------
#Function "is not an element of" (opposite of %in%)
'%!in%' <- function( x, y ) !( '%in%'( x, y ) )


# -----------------------------------------------------------------------------
# repeat_and_add_vector: function for repeating a dataframe in order to add a new vector
repeat_and_add_vector <- function( data, vector, vector_values ) {
     data_new <- data[ rep( 1:nrow( data ), times = length( vector_values ) ), ]
     data_new[[vector]] <- sort( rep( vector_values, length.out = nrow( data_new ) ) )
     return( data_new )
	 }
# -----------------------------------------------------------------------------
#vecpaste: this is a function for pasting together any number of variables to be used as unique identifiers in a lookup
vecpaste <- function (x) {
     y <- x[[1]]
     if (length(x) > 1) {
         for (i in 2:length(x)) {
             y <- paste(y, x[[i]] )
         }
     }
     y
 }


# check whether a data frame contains NaN.
is.nan.data.frame <- function(x)
  do.call(cbind, lapply(x, is.nan))


# add a row of US total
add_USA <- function(x) {
  x1 <- x
  x2 <- x %>%
    summarise_if(is.numeric, sum, na.rm = T) %>%
    mutate(region = "USA")
  result <- rbind(x1, x2)
  
  return(result)
}

is_outlier <- function(x) {
  return((x < quantile(x, 0.25) - 1.5 * IQR(x) | x > quantile(x, 0.75) + 1.5 * IQR(x)))
}

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}
